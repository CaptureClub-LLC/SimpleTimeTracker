=== Time Tracking Plugin ===
Contributors: kevincowan
Tags: time, tracking, admin, chart
Requires at least: 6.8
Tested up to: 6.8.1
Stable tag: 1.1.0
License: GPLv2 or later
